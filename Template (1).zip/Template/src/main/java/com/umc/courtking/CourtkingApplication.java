package com.umc.courtking;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class CourtkingApplication {

    public static void main(String[] args) {
        SpringApplication.run(CourtkingApplication.class, args);
    }

}
