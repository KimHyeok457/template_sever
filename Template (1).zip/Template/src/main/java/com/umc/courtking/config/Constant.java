package com.umc.courtking.config;

public class Constant {
}

